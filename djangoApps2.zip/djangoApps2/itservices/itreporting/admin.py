from django.contrib import admin
from .models import Issue
admin.site.register(Issue)
# Register your models here.
