from django.shortcuts import render
from .models import Issue
#issue = {'name': 'Ben Richardson', 'course':'BSc Hon Computing', 'type': 'Software', 'room':'Building -777', 'details':'VMWare Workstation - Lorem ipsum'}
#>>> issues = {"name": "James Dawson", "course":"BSc Hon Developments", "type": "Software", "room":"Building -776", "details":"VMWare Workstation -  Prima ignota cu mei, deleniti iracundia eu mel. Te vis lorem utamur inciderint."}
#>>> issues = {"name": "Tom Murphy", "course":"BSc Hon Software Engineering", "type": "Software", "room":"Building -773", "details":"VMWare Workstation -  Prima ignota cu mei, deleniti iracundia eu mel. Te vis lorem utamur inciderint."}


def home(request):
 return render(request, 'itreporting/home.html', {'title': 'Home'} )
def about(request):
  return render(request, 'itreporting/about.html', {'title': 'AboutUs'} )
def contact(request):
  return render(request, 'itreporting/contact.html', {'title': 'ContactUs'} )
def report(request):
  daily_report={
    'issues':Issue.objects.all()
  }
  return render(request, 'itreporting/report.html', daily_report)
  #def base(request):
 # return render(request, 'itreporting/base.html')
# Create your views here.
