from django.apps import AppConfig


class ItreportingConfig(AppConfig):
    name = 'itreporting'
